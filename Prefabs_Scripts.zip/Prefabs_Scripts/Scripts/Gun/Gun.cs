using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
    public AudioSource audioSource;
    public AudioClip laserSound;
    public GameObject laser;
    public GameObject[] lasers;
    public Transform barrelLocation;
    public Transform playerLocation;
    private OVRGrabbable ovrGrabbable;
    public OVRInput.Button shootButton;
    public float force = 1500;
    public float velocity = 2000f;

    // Start is called before the first frame update
    [Obsolete]
    void Start()
    {
        laser = lasers[0];
        audioSource = GetComponent<AudioSource>();
        ovrGrabbable = GetComponent<OVRGrabbable>();
        audioSource.clip = laserSound;
    }

    // Update is called once per frame
    void Update()
    {
        // if gun is grabbed and primary trigger is pressed down
        if (ovrGrabbable.isGrabbed && OVRInput.GetDown(shootButton, ovrGrabbable.grabbedBy.GetController()))
        {
            // trigger haptic vibration when gun is fired
            HapticsManager.singleton.TriggerVibration(laserSound, ovrGrabbable.grabbedBy.GetController());
            audioSource.Play();

            // ensure there is a laser asset to instantiate
            if (!laser) { return; }

            // get rotation of barrel
            var rotation = barrelLocation.rotation;
            rotation.x = 0;

            // instantiate projectile and add force
            GameObject projectile = Instantiate(laser, barrelLocation.position, transform.rotation);
            Rigidbody projectileRigidbody = projectile.GetComponent<Rigidbody>();
            projectileRigidbody.AddForce(barrelLocation.right * force);
            projectile.GetComponent<Rigidbody>().AddForce(barrelLocation.right * force);
        }
    }

    // Upgrades gun to fire a different laser
    public void upgradeGun(int level)
    {
        laser = lasers[level];
    }
}

