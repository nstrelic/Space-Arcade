using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameAsteroid : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private int points;
    public float maxHealth = 1f;
    private float currentHealth;
    public AudioClip[] explosionSounds;
    public GameObject explosion;

    // Start is called before the first frame update
    void Start()
    {
        // init current health
        currentHealth = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(-speed * Time.deltaTime, 0, 0);
    }

    // When asteroid is hit by laser
    public void ReactToHit(float damage)
    {
        currentHealth -= damage;

        if (currentHealth <= 0f)
        {
            // destroy object when no health remains
            Explode();
        }
    }

    public void Explode()
    {
        // deactivate object
        foreach (Transform child in transform)
        {
            Destroy(child.gameObject);
        }
        if (GetComponent<SphereCollider>() != null)
            GetComponent<SphereCollider>().enabled = false;
        if (GetComponent<BoxCollider>() != null)
            GetComponent<BoxCollider>().enabled = false;
        // play destroy sound
        PlaySound(explosionSounds[0]);

        // destroy explosion/animation
        var expl = Instantiate(explosion, transform.position, transform.rotation);
        expl.gameObject.GetComponent<ParticleSystem>().Play();
        Die(2.5f);
    }

    // When asteroid comes in contact with the shield
    public void ExplodeOnShield()
    {
        foreach (Transform child in transform)
        {
            if (child.GetComponent<MeshRenderer>() != null)
                child.GetComponent<MeshRenderer>().enabled = false;
        }
        if (GetComponent<SphereCollider>() != null)
            GetComponent<SphereCollider>().enabled = false;
        if (GetComponent<BoxCollider>() != null)
            GetComponent<BoxCollider>().enabled = false;
        // play destroy sound
        PlaySound(explosionSounds[1]);

        // destroy explosion/animation
        var expl = Instantiate(explosion, transform.position, transform.rotation);
        expl.gameObject.GetComponent<ParticleSystem>().Play();
        Die(2.5f);
    }

    // Play audio clip
    public void PlaySound(AudioClip audioClip)
    {
        var audioSource = GetComponent<AudioSource>();
        audioSource.clip = audioClip;
        audioSource.Play();
    }

    public void Die(float timeToDestroy)
    {
        GameObject.Find("ShooterGame").GetComponent<ShooterGameController>().updateScore(points);
        Destroy(gameObject, timeToDestroy);
    }

    public int GetPoints()
    {
        return points;
    }
}
