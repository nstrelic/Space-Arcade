using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shield : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        // if colliding object is a game asteroid
        if (other.gameObject.GetComponent<GameAsteroid>() != null)
        {
            // explode asteroid and reduce players points
            other.gameObject.GetComponent<GameAsteroid>().ExplodeOnShield();
            GameObject.Find("ShooterGame").GetComponent<ShooterGameController>().updateScore(-other.gameObject.GetComponent<GameAsteroid>().GetPoints());
            Destroy(other.gameObject);
            this.GetComponent<AudioSource>().Play();
        }
    }
}
