using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Aliens : MonoBehaviour
{
    public GameObject smoke;
    [SerializeField]
    private AudioClip _spawnSound;
    private AudioSource _audioSource;
    private bool _move;
    [SerializeField]
    private GameObject _alienScream;

    // Start is called before the first frame update
    void Start()
    {
        _move = true;
        _audioSource = GetComponent<AudioSource>();
        _audioSource.PlayOneShot(_spawnSound, _audioSource.volume);
        StartCoroutine(WaitThenDestroy());
        StartCoroutine(WaitFor1());
    }

    // Update is called once per frame
    void Update()
    {
        if(_move)
         transform.Translate(0, 1.0f * Time.deltaTime, 0);
    }

    public void Scream()
    {
        var alienScream = Instantiate(_alienScream, transform.position, transform.rotation);
        alienScream.GetComponent<AudioSource>().Play();
    }

    public void DeathSmoke()
    {
        var smokeEffect = Instantiate(smoke, transform.position, transform.rotation);
        smokeEffect.gameObject.GetComponent<ParticleSystem>().Play();
    }

    IEnumerator WaitFor1()
    {
        yield return new WaitForSeconds(0.5f);
        _move = false;
    }

    IEnumerator WaitThenDestroy()
    {
        yield return new WaitForSeconds(2f);
        Destroy(this.gameObject);
    }
}
