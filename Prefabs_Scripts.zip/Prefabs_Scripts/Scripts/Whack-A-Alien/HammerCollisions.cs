using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HammerCollisions : MonoBehaviour
{
    [SerializeField]
    AudioClip _hapticsClip;
    private OVRGrabbable ovrGrabbable;

    void Start()
    {
        ovrGrabbable = GetComponent<OVRGrabbable>();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.gameObject.tag == "Alien")
        {
            GameObject.Find("Whack-A-Alien Game").GetComponent<WhackAlienController>().UpdateScore();
            collision.collider.gameObject.GetComponent<Aliens>().Scream();
            Destroy(collision.collider.gameObject);
            HapticsManager.singleton.TriggerVibration(_hapticsClip, ovrGrabbable.grabbedBy.GetController());
        }
    }
}
