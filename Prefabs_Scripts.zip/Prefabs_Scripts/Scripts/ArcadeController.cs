using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ArcadeController : MonoBehaviour
{
    private bool _isGameActive;

    // Start is called before the first frame update
    void Start()
    {
        _isGameActive = false;
    }

    public bool IsGameActive()
    {
        return _isGameActive;
    }

    public void ActivateGame()
    {
        _isGameActive = true;
    }

    public void DeactivateGame()
    {
        _isGameActive = false;
    }

    public void ReturnToMainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
