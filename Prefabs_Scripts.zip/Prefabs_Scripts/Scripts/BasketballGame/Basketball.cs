using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Controls the behaviour of the Basketball prefab
public class Basketball : MonoBehaviour
{
    // used to determine if a new ball should spawn
    private bool _inPlay;
    // used to prevent new balls from spawning if the old ball hasn't died
    private bool _active;
    // time for the ball to disappear after entering hoop or hitting the floor
    public int timeToExplode;
    public AudioClip popSound;
    // time before the ball automatically respawns, does not apply if player is holding the ball
    public float _timeToLive;
    private float _timeToLiveCounter;
    private OVRGrabbable ovrGrabbable;
    private bool _hasBeenGrabbed;
    private bool _hasBeenThrown;

    // Start is called before the first frame update
    void Start()
    {
        _inPlay = true;
        _active = true;
        _timeToLiveCounter = _timeToLive;
        _hasBeenThrown = false;
        _hasBeenGrabbed = false;
        ovrGrabbable = GetComponent<OVRGrabbable>();
    }

    // Update is called once per frame
    void Update()
    {
        // if the ball has been thrown, timer is started before ball is set to out of play
        // this prevents the ball from getting stuck and preventing the player from continueing the game
        if (_hasBeenThrown)
        {
            _timeToLiveCounter -= Time.deltaTime;
            if (_timeToLiveCounter <= 0)
            {
                SetInPlay(false);
            }
        }
        
        // if the ball is out of play, but still active,
        // the ball is pop (deactivate) and a new ball will spawn
        if (!_inPlay && _active)
        {
            GameObject.Find("BasketballGame").GetComponent<BasketballGameController>().decrementBalls(1);
            Pop();

            // spawn new ball
            GameObject.Find("BasketballGame").GetComponent<BasketballGameController>().SpawnBall();
        }

        // track whether the ball has been grabbed
        if (ovrGrabbable.isGrabbed)
        {
            _hasBeenGrabbed = true;
        }

        // if the ball has been grabbed, but is no longer being held by the player (ie thrown),
        // set the thrown status to true
        if (!ovrGrabbable.isGrabbed && _hasBeenGrabbed)
        {
            _hasBeenThrown = true;
        }
    }

    // Sets the in play status of the ball
    public void SetInPlay(bool isInPlay)
    {
        _inPlay = isInPlay;
    }

    // Returns the in play status of the ball
    public bool IsInPlay()
    {
        return _inPlay;
    }

    // Sets the active status of the ball
    public void SetActive(bool isActive)
    {
        _active = isActive;
    }

    // Returns the active status of the ball
    public bool IsActive()
    {
        return _active;
    }

    // Pop
    // Deactivate ball, remove collider, play pop sound, and destroy the ball
    private void Pop()
    {
        SetActive(false);
        if (GetComponent<SphereCollider>() != null)
            GetComponent<SphereCollider>().enabled = false;
        // play destroy sound
        PlaySound(popSound);

        // destroy explosion/animation
        Die(timeToExplode);
    }

    // Plays an audio clip
    private void PlaySound(AudioClip audioClip)
    {
        var audioSource = GetComponent<AudioSource>();
        audioSource.clip = audioClip;
        audioSource.Play();
    }

    // Destroys object after timeToDestroy time
    private void Die(float timeToDestroy)
    {
        Destroy(gameObject, timeToDestroy);
    }
}
