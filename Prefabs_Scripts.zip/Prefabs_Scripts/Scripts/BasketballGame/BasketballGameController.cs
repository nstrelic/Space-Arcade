using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

// Controls the behaviour of the basketball game
public class BasketballGameController : MonoBehaviour
{
    public GameObject ballSpawner;
    public GameObject basketball;
    public AudioClip gameOverClip;
    private bool _isGameStarted;
    private int _currentScore;
    private float _timeLeft;
    private int _scoreMultiplier;
    private int _maxBalls = 1;
    private int _currentBalls;
    private ArcadeController _arcadeController;

    // function that is called from button press to start game
    public void StartBasketballGame()
    {
        _arcadeController = GameObject.Find("Arcade").GetComponent<ArcadeController>();
        // Only 1 arcade game can be active at a time
        if (!_arcadeController.IsGameActive())
        {
            GameObject.Find("BasketballGameAudio").GetComponent<AudioSource>().Play();
            _arcadeController.ActivateGame();
            _isGameStarted = true;
            _timeLeft = 60f;
            _scoreMultiplier = 1;
            _currentBalls = 0;

            SpawnBall();
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        _isGameStarted = false;
        GameObject.Find("BasketballScore").GetComponent<TextMeshPro>().text = "Highscore: " + PlayerPrefs.GetInt("BasketballGame_Highscore").ToString();
    }

    // Update is called once per frame
    void Update()
    {
        if (_isGameStarted)
        {
            // game timer
            _timeLeft -= Time.deltaTime;
            GameObject.Find("BasketballTimer").GetComponent<TextMeshPro>().text = ((int)_timeLeft).ToString();
            if (_timeLeft <= 0)
                GameOver();
        }
    }

    // Adjusts score by the passed value
    public void UpdateScore(int scoreChange)
    {
        // Apply multiplier to score change
        _currentScore += scoreChange * _scoreMultiplier;
        // Increase multiplier for the next basket
        IncreaseMultiplier();
        GameObject.Find("BasketballScore").GetComponent<TextMeshPro>().text = _currentScore.ToString();
    }

    // When timer reaches 0
    private void GameOver()
    {
        AudioSource audioSource = GameObject.Find("BasketballGameAudio").GetComponent<AudioSource>();
        audioSource.Stop();
        audioSource.PlayOneShot(gameOverClip, audioSource.volume);
        _isGameStarted = false;
        _arcadeController.DeactivateGame();

        // update highscore if applicable
        if (_currentScore > PlayerPrefs.GetInt("BasketballGame_Highscore"))
        {
            PlayerPrefs.SetInt("BasketballGame_Highscore", _currentScore);
        }

        // destroy basketballs
        var basketballs = GameObject.FindGameObjectsWithTag("Basketball");
        foreach (var b in basketballs)
        {
            Destroy(b);
        }
    }

    // Increase multiplier
    // Occurs when player makes a shot
    public void IncreaseMultiplier()
    {
        _scoreMultiplier += 1;
    }

    // Resets multiplier
    // Occurs when the player misses a shot
    public void ResetMutliplier()
    {
        _scoreMultiplier = 1;
    }

    // Spawns a new ball
    public void SpawnBall()
    {
        // Cannot be more than 1 active ball in the scene at a time
        if (_currentBalls < _maxBalls)
        {
            Instantiate(basketball, ballSpawner.transform.position, ballSpawner.transform.rotation);
            incrementBalls(1);
        }
    }

    // Decrease number of balls in scene
    public void decrementBalls(int dec)
    {
        _currentBalls--;
    }

    // Increase number of balls in scene
    public void incrementBalls(int inc)
    {
        _currentBalls++;
    }
}
