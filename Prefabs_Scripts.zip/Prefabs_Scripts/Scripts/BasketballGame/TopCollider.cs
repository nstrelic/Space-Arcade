using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TopCollider : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        // if colliding object is basketball
        if (other.gameObject.GetComponent<Basketball>() != null)
        {
            // Player made shot, increment score and take ball out of play
            GameObject.Find("BasketballGame").GetComponent<BasketballGameController>().UpdateScore(1);
            other.gameObject.GetComponent<Basketball>().SetInPlay(false);
        }
    }
}
