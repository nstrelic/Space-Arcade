using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloorCollider : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        // if colliding object is a basketball
        if (other.gameObject.GetComponent<Basketball>() != null)
        {
            // if basketball is in play
            if (other.gameObject.GetComponent<Basketball>().IsInPlay())
            {
                // Player missed shot, reset multiplier
                BasketballGameController gameController = GameObject.Find("BasketballGame").GetComponent<BasketballGameController>();
                gameController.ResetMutliplier();
            }
            // Ball no longer in play, missed shot
            other.gameObject.GetComponent<Basketball>().SetInPlay(false);
        }
    }
}
