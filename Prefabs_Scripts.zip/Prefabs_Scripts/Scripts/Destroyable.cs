using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroyable : MonoBehaviour
{
    public float maxHealth = 1f;
    private float currentHealth;
    public AudioClip explosionSound;
    public GameObject explosion;

    // Start is called before the first frame update
    void Start()
    {
        // init current health
        currentHealth = maxHealth;
    }

    public void ReactToHit(float damage)
    {
        currentHealth -= damage;

        if (currentHealth <= 0f)
        {
            // play destroy sound
            Explode();
        }
    }

    public void Explode()
    {
        // deactivate object
        foreach (Transform child in transform)
        {
            Destroy(child.gameObject);
        }
        if (GetComponent<SphereCollider>() != null)
            GetComponent<SphereCollider>().enabled = false;
        if (GetComponent<BoxCollider>() != null)
            GetComponent<BoxCollider>().enabled = false;
        // play destroy sound
        PlaySound(explosionSound);

        // destroy explosion/animation
        var expl = Instantiate(explosion, transform.position, transform.rotation);
        expl.gameObject.GetComponent<ParticleSystem>().Play();
        Die(2.5f);
    }

    public void PlaySound(AudioClip audioClip)
    {
        var audioSource = GetComponent<AudioSource>();
        audioSource.clip = audioClip;
        audioSource.Play();
    }

    public void Die(float timeToDestroy)
    {
        Destroy(gameObject, timeToDestroy);
    }
}
